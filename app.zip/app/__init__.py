"""SEO Audit Agent."""
__version__ = "1.0.0"

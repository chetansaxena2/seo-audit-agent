"""Competitor discovery and comparison.

Competitors are found from the site's own services + location (or supplied by
the caller), then crawled lightly and compared on the signals that actually
move rankings.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from urllib.parse import urlparse

import httpx

from .. import llm
from .. import textutil as T
from ..config import settings
from ..crawler import Crawler, SiteContext
from ..parser import PageData

AGGREGATORS = {
    "facebook.com", "instagram.com", "linkedin.com", "twitter.com", "x.com", "youtube.com",
    "wikipedia.org", "quora.com", "reddit.com", "pinterest.com", "yelp.com", "tripadvisor.com",
    "justdial.com", "indiamart.com", "sulekha.com", "amazon.com", "flipkart.com", "google.com",
    "maps.google.com", "yellowpages.com", "glassdoor.com", "indeed.com", "medium.com",
    "makemytrip.com", "goibibo.com", "booking.com", "trivago.com", "olx.in", "99acres.com",
}


@dataclass
class Competitor:
    domain: str
    url: str
    name: str = ""
    source: str = ""
    title: str = ""
    meta_description: str = ""
    h1: str = ""
    word_count: int = 0
    schema_types: list[str] = field(default_factory=list)
    has_faq_schema: bool = False
    has_llms_txt: bool = False
    images_with_alt_pct: float = 0.0
    internal_links: int = 0
    keyword_hits: dict[str, bool] = field(default_factory=dict)
    load_ms: int = 0
    page_kb: float = 0.0
    strengths: list[str] = field(default_factory=list)
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "url": self.url,
            "name": self.name,
            "found_via": self.source,
            "title": self.title,
            "title_length": len(self.title),
            "meta_description_length": len(self.meta_description),
            "h1": self.h1,
            "word_count": self.word_count,
            "schema_types": self.schema_types,
            "has_faq_schema": self.has_faq_schema,
            "has_llms_txt": self.has_llms_txt,
            "images_with_alt_pct": round(self.images_with_alt_pct, 1),
            "internal_links": self.internal_links,
            "keyword_coverage": self.keyword_hits,
            "load_ms": self.load_ms,
            "page_kb": round(self.page_kb, 1),
            "strengths": self.strengths,
            "error": self.error,
        }


async def _serper(query: str, count: int) -> list[dict]:
    if not settings.serper_api_key:
        return []
    try:
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post("https://google.serper.dev/search",
                             json={"q": query, "num": max(10, count * 3)},
                             headers={"X-API-KEY": settings.serper_api_key,
                                      "Content-Type": "application/json"})
            r.raise_for_status()
            data = r.json()
    except Exception:
        return []
    out = []
    for item in data.get("organic", []):
        out.append({"url": item.get("link", ""), "name": item.get("title", ""),
                    "source": "serper/google"})
    return out


async def _google_cse(query: str, count: int) -> list[dict]:
    if not (settings.google_api_key and settings.google_cse_id):
        return []
    try:
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.get("https://www.googleapis.com/customsearch/v1",
                            params={"key": settings.google_api_key, "cx": settings.google_cse_id,
                                    "q": query, "num": 10})
            r.raise_for_status()
            data = r.json()
    except Exception:
        return []
    return [{"url": i.get("link", ""), "name": i.get("title", ""), "source": "google-cse"}
            for i in data.get("items", [])]


async def _llm_search(query: str, own_domain: str, count: int) -> list[dict]:
    if not llm.available():
        return []
    data = await llm.complete_json(
        f"Search the web for businesses competing for the query: \"{query}\". "
        f"Ignore the domain {own_domain}, directories, marketplaces and social networks. "
        f"Return the {count} strongest direct competitor businesses as JSON: "
        "[{\"name\": str, \"url\": str}]",
        tools=llm.WEB_SEARCH_TOOL, max_tokens=1200)
    if not isinstance(data, list):
        return []
    return [{"url": d.get("url", ""), "name": d.get("name", ""), "source": "llm-web-search"}
            for d in data if isinstance(d, dict) and d.get("url")]


def _clean(cands: list[dict], own_domain: str, count: int) -> list[dict]:
    out: list[dict] = []
    seen: set[str] = set()
    for c in cands:
        url = c.get("url") or ""
        if not url.startswith("http"):
            continue
        host = urlparse(url).netloc.lower().replace("www.", "")
        if not host or host in seen:
            continue
        if host == own_domain or own_domain in host or host in own_domain:
            continue
        if any(host == a or host.endswith("." + a) for a in AGGREGATORS):
            continue
        seen.add(host)
        out.append({"domain": host, "url": f"https://{host}/",
                    "name": c.get("name", host), "source": c.get("source", "")})
        if len(out) >= count:
            break
    return out


async def discover(ctx: SiteContext, services: list[str], location: str,
                   supplied: list[str] | None, count: int) -> list[dict]:
    if supplied:
        return _clean([{"url": u if u.startswith("http") else f"https://{u}",
                        "name": u, "source": "user-supplied"} for u in supplied],
                      ctx.netloc.replace("www.", ""), count)
    own = ctx.netloc.replace("www.", "")
    service = services[0] if services else "services"
    query = f"{service} {location}".strip() or own
    results = await _serper(query, count)
    if not results:
        results = await _google_cse(query, count)
    if not results:
        results = await _llm_search(query, own, count)
    cleaned = _clean(results, own, count)
    if len(cleaned) < count and len(services) > 1:
        more = await _serper(f"{services[1]} {location}".strip(), count) \
            or await _google_cse(f"{services[1]} {location}".strip(), count)
        cleaned = _clean([{"url": c["url"], "name": c.get("name", ""), "source": c.get("source", "")}
                          for c in cleaned] + more, own, count)
    return cleaned


async def profile_one(crawler: Crawler, cand: dict, keywords: list[str]) -> Competitor:
    comp = Competitor(domain=cand["domain"], url=cand["url"],
                      name=cand.get("name", ""), source=cand.get("source", ""))
    page: PageData = await crawler.fetch(cand["url"], root_netloc=cand["domain"])
    if not page.html:
        comp.error = page.error or f"HTTP {page.status}"
        return comp
    comp.title = page.title
    comp.meta_description = page.meta_description
    comp.h1 = page.h1s[0].text if page.h1s else ""
    comp.word_count = page.word_count
    comp.schema_types = page.schema_types
    comp.has_faq_schema = page.has_schema("FAQPage")
    comp.internal_links = len(page.internal_links)
    comp.load_ms = page.load_ms
    comp.page_kb = page.bytes / 1024
    if page.images:
        comp.images_with_alt_pct = 100 * sum(
            1 for i in page.images if (i.alt or "").strip()) / len(page.images)
    blob = f"{page.title} {page.heading_text} {page.main_text}"
    comp.keyword_hits = {k: T.contains_phrase(blob, k) for k in keywords[:8]}

    status, text = await crawler.fetch_text(f"https://{comp.domain}/llms.txt")
    comp.has_llms_txt = status == 200 and "<html" not in text[:300].lower()

    if comp.word_count > 800:
        comp.strengths.append(f"long-form homepage ({comp.word_count} words)")
    if comp.has_faq_schema:
        comp.strengths.append("FAQ schema implemented")
    if comp.schema_types:
        comp.strengths.append(f"schema: {', '.join(comp.schema_types[:3])}")
    if comp.has_llms_txt:
        comp.strengths.append("publishes llms.txt")
    if comp.images_with_alt_pct > 90:
        comp.strengths.append("full image alt coverage")
    if comp.load_ms and comp.load_ms < 1200:
        comp.strengths.append(f"fast homepage ({comp.load_ms}ms)")
    return comp


def compare(own: PageData, own_keywords: list[str], comps: list[Competitor]) -> dict:
    """Turn the competitor profiles into gaps the client can act on."""
    live = [c for c in comps if not c.error]
    if not live:
        return {"gaps": [], "wins": [], "summary": "No competitor data available."}
    own_blob = f"{own.title} {own.heading_text} {own.main_text}"
    own_profile = {
        "word_count": own.word_count,
        "schema_types": own.schema_types,
        "has_faq_schema": own.has_schema("FAQPage"),
        "images_with_alt_pct": (100 * sum(1 for i in own.images if (i.alt or "").strip())
                                / len(own.images)) if own.images else 0,
        "load_ms": own.load_ms,
        "title_length": len(own.title),
    }
    gaps, wins = [], []
    avg_words = sum(c.word_count for c in live) / len(live)
    if own.word_count < avg_words * 0.75:
        gaps.append(f"Homepage content is {own.word_count} words vs a competitor average of "
                    f"{avg_words:.0f} — expand depth to compete.")
    elif own.word_count > avg_words * 1.25:
        wins.append(f"Homepage depth ({own.word_count} words) beats the competitor average "
                    f"({avg_words:.0f}).")

    if not own_profile["has_faq_schema"] and any(c.has_faq_schema for c in live):
        gaps.append("Competitors use FAQ schema and you do not — they are eligible for FAQ rich "
                    "results and AI answers you are missing.")
    if not own.schema_types and any(c.schema_types for c in live):
        gaps.append("Competitors ship structured data and this site has none.")
    if any(c.has_llms_txt for c in live) and True:
        gaps.append("A competitor publishes llms.txt — they are optimising for AI assistants first.")
    if own_profile["images_with_alt_pct"] < 60 and any(c.images_with_alt_pct > 80 for c in live):
        gaps.append("Competitor image alt coverage is far higher, giving them image-search reach.")
    fast = [c.load_ms for c in live if c.load_ms]
    if fast and own.load_ms > min(fast) * 1.5:
        gaps.append(f"Fastest competitor homepage loads in {min(fast)}ms vs {own.load_ms}ms here.")
    elif fast and own.load_ms < min(fast):
        wins.append(f"Homepage responds faster ({own.load_ms}ms) than every competitor checked.")

    keyword_gaps = []
    for kw in own_keywords[:8]:
        theirs = sum(1 for c in live if c.keyword_hits.get(kw))
        mine = T.contains_phrase(own_blob, kw)
        if theirs and not mine:
            keyword_gaps.append(kw)
    if keyword_gaps:
        gaps.append("Keywords competitors target on their homepage that this site does not: "
                    + ", ".join(keyword_gaps[:6]))

    return {
        "own_profile": own_profile,
        "competitor_average_words": round(avg_words),
        "gaps": gaps,
        "wins": wins,
        "keyword_gaps": keyword_gaps,
    }


async def analyse(ctx: SiteContext, pages: list[PageData], services: list[str], location: str,
                  keywords: list[str], supplied: list[str] | None = None) -> dict:
    if not settings.competitors_enabled:
        return {"enabled": False, "competitors": [], "comparison": {}}
    count = settings.competitor_count
    cands = await discover(ctx, services, location, supplied, count)
    if not cands:
        return {
            "enabled": True, "competitors": [], "comparison": {},
            "note": ("No competitor source configured. Set SERPER_API_KEY, GOOGLE_API_KEY + "
                     "GOOGLE_CSE_ID or ANTHROPIC_API_KEY, or pass competitors in the request."),
        }
    async with Crawler() as crawler:
        comps = await asyncio.gather(*[profile_one(crawler, c, keywords) for c in cands])
    own = next((p for p in pages if p.html), None)
    comparison = compare(own, keywords, list(comps)) if own else {}
    return {
        "enabled": True,
        "query_used": f"{services[0] if services else ''} {location}".strip(),
        "competitors": [c.to_dict() for c in comps],
        "comparison": comparison,
    }

"""Report rendering (HTML + PDF)."""

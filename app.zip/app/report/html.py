"""Renders the audit payload into a single self-contained HTML file.

Screenshots are inlined as base64 so the report can be emailed, hosted or
printed to PDF without any external dependencies.
"""
from __future__ import annotations

import base64
import json
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from ..config import settings

TEMPLATES = Path(__file__).parent / "templates"
LIMITS = {"critical": 30, "high": 30, "medium": 25, "low": 20}

_env = Environment(
    loader=FileSystemLoader(str(TEMPLATES)),
    autoescape=select_autoescape(["html"]),
    trim_blocks=True,
    lstrip_blocks=True,
)


def _color(value: float) -> str:
    if value >= 80:
        return "#0E9F6E"
    if value >= 60:
        return "#00A6A6"
    if value >= 40:
        return "#D98200"
    return "#C3222B"


def _inline_image(path: str | None) -> str | None:
    if not path:
        return None
    p = Path(path)
    if not p.exists() or p.stat().st_size > 4_000_000:
        return None
    return "data:image/png;base64," + base64.b64encode(p.read_bytes()).decode()


def render(result: dict) -> str:
    data = json.loads(json.dumps(result))  # deep copy, JSON-safe
    for sev, items in data.get("roadmap", {}).items():
        for issue in items:
            issue["screenshot_data"] = _inline_image(issue.get("screenshot"))
    template = _env.get_template("report.html.j2")
    return template.render(r=data, color=_color, limits=LIMITS)


def write(result: dict, audit_id: str, out_dir: str | Path | None = None) -> str:
    out_dir = Path(out_dir) if out_dir else Path(settings.data_dir) / "reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{audit_id}.html"
    path.write_text(render(result), encoding="utf-8")
    return str(path)
